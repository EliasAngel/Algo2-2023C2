package diccionario

import (
	TDAPila "tdas/pila"
)

type abb[K comparable, V any] struct {
	raiz       *nodo[K, V]
	cantidad   int
	funcionCmp func(K, K) int
}

type nodo[K comparable, V any] struct {
	clave   K
	dato    V
	hijoIzq *nodo[K, V]
	hijoDer *nodo[K, V]
}

// crearNodo crea un nodo del arbol
func crearNodo[K comparable, V any](clave K, dato V) *nodo[K, V] {
	return &nodo[K, V]{clave: clave, dato: dato}
}

// CrearABB Inicializa un arbol vacio con la funcion de comparacion pasada por parametro
func CrearABB[K comparable, V any](funcionCmp func(K, K) int) DiccionarioOrdenado[K, V] {
	return &abb[K, V]{funcionCmp: funcionCmp}
}

func (a *abb[K, V]) buscarPosicion(act *nodo[K, V], padre *nodo[K, V], clave K) (*nodo[K, V], *nodo[K, V]) {
	if act == nil {
		return act, padre
	}
	if a.funcionCmp(act.clave, clave) < 0 {
		return a.buscarPosicion(act.hijoDer, act, clave)
	} else if a.funcionCmp(act.clave, clave) > 0 {
		return a.buscarPosicion(act.hijoIzq, act, clave)
	} else {
		return act, padre
	}
}

// Guardar guarda el par clave-dato en el Diccionario. Si la clave ya se encontraba, se actualiza el dato asociado
func (a *abb[K, V]) Guardar(clave K, dato V) {
	act, padre := a.buscarPosicion(a.raiz, nil, clave)
	if act != nil {
		act.dato = dato
	} else {
		nuevo := crearNodo(clave, dato)
		if padre == nil {
			a.raiz = nuevo
		} else if a.funcionCmp(clave, padre.clave) < 0 {
			padre.hijoIzq = nuevo
		} else if a.funcionCmp(clave, padre.clave) > 0 {
			padre.hijoDer = nuevo
		}
		a.cantidad++
	}
}

// Pertenece determina si una clave ya se encuentra en el abb, o no
func (a *abb[K, V]) Pertenece(clave K) bool {
	nodo, _ := a.buscarPosicion(a.raiz, nil, clave)
	return nodo != nil
}

// Obtener devuelve el dato asociado a una clave. Si la clave no pertenece, debe entrar en pánico con mensaje
// 'La clave no pertenece al diccionario'
func (a *abb[K, V]) Obtener(clave K) V {
	nodo, _ := a.buscarPosicion(a.raiz, nil, clave)
	if nodo == nil {
		panic("La clave no pertenece al diccionario")
	}
	return nodo.dato
}

// cantHijos determina la cantidad de hijos que tiene un nodo
func (n *nodo[K, V]) cantHijos() int {
	resultado := 0
	if n.hijoDer != nil {
		resultado++
	}
	if n.hijoIzq != nil {
		resultado++
	}
	return resultado
}

// Borrar borra del Diccionario la clave indicada, devolviendo el dato que se encontraba asociado. Si la clave no
// pertenece al diccionario, debe entrar en pánico con un mensaje 'La clave no pertenece al diccionario'
func (a *abb[K, V]) Borrar(clave K) V {
	act, padre := a.buscarPosicion(a.raiz, nil, clave)
	if act == nil {
		panic("La clave no pertenece al diccionario")
	}
	dato := act.dato
	hijos := act.cantHijos()
	if hijos == 0 {
		if padre == nil {
			a.raiz = nil
		} else {
			if a.funcionCmp(clave, padre.clave) < 0 {
				padre.hijoIzq = nil
			} else if a.funcionCmp(clave, padre.clave) > 0 {
				padre.hijoDer = nil
			}
		}
	}
	if hijos == 1 {
		if act.hijoIzq != nil {
			act = act.hijoIzq
			if padre == nil {
				a.raiz = act
			} else {
				if a.funcionCmp(act.clave, padre.clave) < 0 {
					padre.hijoIzq = act
				} else if a.funcionCmp(act.clave, padre.clave) > 0 {
					padre.hijoDer = act
				}
			}
		} else if act.hijoDer != nil {
			act = act.hijoDer
			if padre == nil {
				a.raiz = act
			} else {
				if a.funcionCmp(act.clave, padre.clave) < 0 {
					padre.hijoIzq = act
				} else if a.funcionCmp(act.clave, padre.clave) > 0 {
					padre.hijoDer = act
				}
			}
		}
	}
	if hijos == 2 {
		reemplazante := a.buscarReemplazante(act)
		claveReemplazar := reemplazante.clave
		datoReemplazar := a.Borrar(reemplazante.clave)
		act.clave = claveReemplazar
		act.dato = datoReemplazar
		a.cantidad++ //Al borrar el reemplazante, se quita uno a la cantidad, pero tambien se quita uno cuando sale de este if, por eso se suma uno
	}
	a.cantidad--
	return dato
}

// La funcion se mueve un hijo para la derecha y despues hacia la izquierda hasta llegar a un nodo sin hijos izquierdos
// para asi llegar a lo que seria el siguiente elemento inorder del arbol
func (a *abb[K, V]) buscarReemplazante(act *nodo[K, V]) *nodo[K, V] {
	reemplazo := act.hijoDer
	for reemplazo.hijoIzq != nil {
		reemplazo = reemplazo.hijoIzq
	}
	return reemplazo
}

// Cantidad devuelve la cantidad de elementos dentro del hash
func (a *abb[K, V]) Cantidad() int {
	return a.cantidad
}

// Iterar itera el arbol completo en recorrido INORDER (se procesa la raiz entre los nodos)
func (a *abb[K, V]) Iterar(f func(clave K, dato V) bool) {
	a.IterarRango(nil, nil, f)
}

// IterarRango recorre el arbol dentro de un rango designado por parametro
func (a *abb[K, V]) IterarRango(desde *K, hasta *K, visitar func(clave K, dato V) bool) {
	if desde == nil {
		desde = a.buscarMinimo()
	}
	if hasta == nil {
		hasta = a.buscarMaximo()
	}
	continuar := true
	a.raiz.iterarAuxiliar(desde, hasta, visitar, a.funcionCmp, &continuar)
}

// iterarAuxiliar se encarga de que el arbol se recorra correctamente, respetando el rango recibido,
// verifica que cada nodo visitado devuelva true, y corta toda la iteracion en caso contrario
func (n *nodo[K, V]) iterarAuxiliar(desde *K, hasta *K, visitar func(clave K, dato V) bool, cmp func(K, K) int, continuar *bool) {
	if n == nil {
		return
	}
	if n.hijoIzq != nil && cmp(*desde, n.clave) <= 0 {
		n.hijoIzq.iterarAuxiliar(desde, hasta, visitar, cmp, continuar)
	}
	if !*continuar {
		return
	}
	if cmp(*desde, n.clave) <= 0 && cmp(*hasta, n.clave) >= 0 {
		*continuar = visitar(n.clave, n.dato)
	}
	if !*continuar {
		return
	}
	if n.hijoDer != nil && cmp(*hasta, n.clave) >= 0 {
		n.hijoDer.iterarAuxiliar(desde, hasta, visitar, cmp, continuar)
	}
}

// buscarMinimo busca el inicio del recorrido INORDER
func (a *abb[K, V]) buscarMinimo() *K {
	if a.raiz == nil {
		return nil
	}
	minimo := a.raiz
	for minimo.hijoIzq != nil {
		minimo = minimo.hijoIzq
	}
	return &minimo.clave
}

// buscarMaximo busca el final del recorrido INORDER
func (a *abb[K, V]) buscarMaximo() *K {
	if a.raiz == nil {
		return nil
	}
	maximo := a.raiz
	for maximo.hijoDer != nil {
		maximo = maximo.hijoDer
	}
	return &maximo.clave
}

// Implementacion del iterador externo del ABB
type iteradorABB[K comparable, V any] struct {
	arbol      abb[K, V]
	recorrido  TDAPila.Pila[*nodo[K, V]]
	funcionCmp func(K, K) int
	desde      *K
	hasta      *K
}

func (a *abb[K, V]) Iterador() IterDiccionario[K, V] {
	return a.IteradorRango(nil, nil)
}

func (a *abb[K, V]) IteradorRango(desde *K, hasta *K) IterDiccionario[K, V] {
	iter := new(iteradorABB[K, V])
	recorrido := TDAPila.CrearPilaDinamica[*nodo[K, V]]()
	iter.desde, iter.hasta = desde, hasta
	if desde == nil {
		iter.desde = a.buscarMinimo()
	}
	if hasta == nil {
		iter.hasta = a.buscarMaximo()
	}
	iter.funcionCmp = a.funcionCmp
	iter.recorrido = iter.recorridoIterador(a.raiz, recorrido)
	return iter
}

func (iter *iteradorABB[K, V]) HaySiguiente() bool {
	return !iter.recorrido.EstaVacia()
}

func (iter *iteradorABB[K, V]) VerActual() (K, V) {
	if !iter.HaySiguiente() {
		panic("El iterador termino de iterar")
	}
	nodo := iter.recorrido.VerTope()
	return nodo.clave, nodo.dato
}

func (iter *iteradorABB[K, V]) Siguiente() {
	if !iter.HaySiguiente() {
		panic("El iterador termino de iterar")
	}
	nodo := iter.recorrido.Desapilar()
	if nodo.hijoDer != nil {
		iter.recorridoIterador(nodo.hijoDer, iter.recorrido)
	}
}

// recorridoIterador apila el nodo que se pasa por parametro y el subarbol izquierdo del mismo
func (iter *iteradorABB[K, V]) recorridoIterador(nodo *nodo[K, V], recorrido TDAPila.Pila[*nodo[K, V]]) TDAPila.Pila[*nodo[K, V]] {
	if nodo == nil {
		return recorrido
	}
	if iter.funcionCmp(*iter.desde, nodo.clave) <= 0 && iter.funcionCmp(*iter.hasta, nodo.clave) >= 0 {
		recorrido.Apilar(nodo)
	} else if iter.funcionCmp(*iter.desde, nodo.clave) >= 0 {
		recorrido = iter.recorridoIterador(nodo.hijoDer, recorrido)
	}
	recorrido = iter.recorridoIterador(nodo.hijoIzq, recorrido)
	return recorrido
}
